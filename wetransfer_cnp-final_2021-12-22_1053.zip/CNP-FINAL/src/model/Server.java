package model;

import java.io.*;
import java.net.ServerSocket;
import java.net.Socket;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.security.SecureRandom;
import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;

import static java.lang.Thread.currentThread;

public class Server {
    private final String UsersAndPasswordDATABASE;
    private final String connectedUsersDATABASE;
    private final String tempFile;
    private final String conversationsPath;

    // Storing the sockets and usernames : faster than going into the database everytime we need it
    private ArrayList<Socket> connectedClients_sockets = new ArrayList<Socket>();
    private ArrayList<String> connectedClients_usernames = new ArrayList<String>();

    private ServerSocket serverSocket;
    private int port;

    public Server (int port, String UsersAndPasswordDATABASE, String connectedUsersDATABASE, String tempFile, String conversationsPath) throws IOException {
        // ---------------------------------------------- INITIALIZATION ----------------------------------------------
        // PORT
        this.port = port;

        // SOCKET
        this.serverSocket = new ServerSocket(port);

        // PATHs initialization
        this.UsersAndPasswordDATABASE = UsersAndPasswordDATABASE;
        this.connectedUsersDATABASE = connectedUsersDATABASE;
        this.tempFile = tempFile;
        this.conversationsPath = conversationsPath;

        // clean the UsersConnectedDATABASE
        initialization();
    }


    // ----------------------------------------------------- MAIN -----------------------------------------------------

    public void run() throws IOException {
        while(true) {
            // ------------------------------------- WAITS FOR A CLIENT TO CONNECT -------------------------------------
            // (1) Waits for a client to connect
            System.out.println("Waiting for client connection ...");

            // ------------------------------------- ACCEPTS THE CLIENT CONNECTION -------------------------------------
            // (2) Accepts the client connection
            Socket client = serverSocket.accept();
            System.out.println("Client connected");

            // ------------------------------------------- THREAD LAUNCHING -------------------------------------------
            // (3) Launch a thread for this client : manager => One manager per client
            new Thread(() -> {
                try {
                    manageClient(client);
                } catch (IOException ex) {
                    ex.printStackTrace();
                }
            }).start();
        }
    }


    // ------------------------------------------------ CLIENT MANAGER ------------------------------------------------

    private void manageClient(Socket socket) throws IOException {
        /*
        Thread managing only one client
         */
        // --------------------------- INITIALIZATION OF WRITER, READER AND LOCAL VARIABLES ---------------------------
        BufferedReader fromClient = new BufferedReader(new InputStreamReader(socket.getInputStream()));
        PrintWriter toClient = new PrintWriter(socket.getOutputStream(), true);
        boolean clientLoggedIn = false; // 1 if logged in, 0 otherwise
        String username = null;

        // --------------------------------------------- CLIENT LOGGING IN ---------------------------------------------
        while (!clientLoggedIn){
            toClient.println("SIGN UP (s) or LOGIN (l) ?");
            String answer = fromClient.readLine();
            if (answer.equals("s")) { // SIGN UP : the user is new and creates his account
                // USERNAME
                toClient.println("What is your username ?");
                username = fromClient.readLine();
                while (!correctNewUsername(username)) { // correct means : does not already exist + no spaces
                    if (username.contains(" ")) { // if there is at least one space ...
                        toClient.println("Please do not put spaces in you username. What is your username ?");
                    } else { // if the username is already taken by another client
                        toClient.println("This username already exists, please try again. What is your username ?");
                    }
                    username = fromClient.readLine(); // read the client's request (proposal for username)
                }
                // PASSWORD
                toClient.println("passwordSignIn"); // the server asks the client to send his hashed password
                String passwordHash = fromClient.readLine();

                // The server tells the client that he's logged in and agrees its username : the client can then save it
                toClient.println("Logged in.");
                toClient.println(username);

                // We must save the username + passwordHash in a database
                newUserSignedUp(username, passwordHash);

                // Display
                System.out.println("[NEW USER] => " + username + " is now connected !");

                // Update
                clientLoggedIn = true;
            }
            else if (answer.equals("l")) { // LOGIN : the user already has an account and login into it
                // USERNAME
                toClient.println("What is your username ?");
                username = fromClient.readLine();
                while (!usernameAlreadyExists(username) || userAlreadyConnected(username)) { // We must be sure that the username exists and is not already connected ...
                    if (userAlreadyConnected(username)){ // if he is already connected ...
                        toClient.println("This username seems to already be connected here ... Please try again with another account or sign up");
                    }
                    else { // if the username does not exist ...
                        toClient.println("This username does not exist, please try again or sign up. What is your username ?");
                    }
                    username = fromClient.readLine(); // read the client's request (proposal for username)
                }
                // PASSWORD => Challenge-Response
                // (1) Nonce generation
                String nonceString = getNonce();
                // (2) Challenge : sends the nonce to the client
                toClient.println("challenge " + nonceString);
                // (3) Response : from the client, the server receives H(H(password)+nonceString) and it must generate it here too and compare : if they match, the authentication is done; otherwise, the user must try again.
                String hashedPWandNonce = fromClient.readLine();
                // (4) Find in the database H(pw) and generate the real H(H(pw)+nonce)
                String realHashedPW = getRealHashedPW(username);
                String realHashedPWandNonce = String.valueOf((realHashedPW+nonceString).hashCode());
                // (5) Authentication : comparison of the two H(H(pw)+nonce)
                while (!realHashedPWandNonce.equals(hashedPWandNonce)) { // We must repeat until it does match ; otherwise, the authentication fails
                    nonceString = getNonce(); // (1)
                    toClient.println("tryAgainChallenge " + nonceString); // (2)
                    hashedPWandNonce = fromClient.readLine(); // (3)
                    realHashedPW = getRealHashedPW(username); // (4)
                    realHashedPWandNonce = String.valueOf((realHashedPW+nonceString).hashCode()); // (4)
                    // go to (5)
                }

                // The server tells the client that he's logged in and agrees its username : the client can then save it
                toClient.println("Logged in.");
                toClient.println(username);

                // Display
                System.out.println("[LOGIN] " + username + " is now logged in and authenticated !");

                // Update
                clientLoggedIn = true;
            }
            else if (answer.startsWith("quit")) { // If the user wants to quit directly after launching the client (why not ...)
                System.out.println("A client which is not connected yet is quitting.");
                currentThread().stop();
            }
        }
        // THE USER IS NOW CONNECTED
        userConnected(username, socket);

        // ------------------------------------ CONTINUOUS MONITORING OF THE CLIENT ------------------------------------
        while (true) {
            // (1) Listens to the client
            String request = fromClient.readLine();

            // (2) Acts on the client request
            if (request.startsWith("quit")) { // IF THE CLIENT WANTS TO QUIT
                String[] requestArray = request.split(" ", 2);
                String userToDisconnect = requestArray[1];
                System.out.println(userToDisconnect + " is quitting.");
                // The server disconnects the user : forgets him in the database connectedUsers
                userDisconnected(userToDisconnect);
                // The server tells the client that everything is done for him : he can disconnect for real => he can close the socket
                toClient.println("DISCONNECTED"); // The client is closing the socket and because we are using TCP protocol, the server automatically close its socket with this client
                // The server stop the current Thread which means he does not have to manage this client anymore ...
                currentThread().stop();
            }

            if (request.equals("USERS")) { // IF THE CLIENT WANTS TO KNOW ALL THE CONNECTED USERS
                // Sends the list of all the connected users to the client
                sendConnectedUsers(toClient);
            }

            if (request.startsWith("conv")) { // IF THE CLIENT WANTS TO LOAD ALL THE CONVERSATION WITH A CERTAIN OTHER USER
                String[] requestArray = request.split(" ", 3);
                ArrayList<String> users = new ArrayList<String>(); users.add(requestArray[1]); users.add(requestArray[2]);
                // Sends the conversation history to the client
                sendConvHistory(users, toClient);
            }

            if (request.startsWith("talkTo")){// IF THE CLIENT WANTS TO START A CONVERSATION WITH SOMEONE
                // First decode to define the source and the destination
                String[] requestArray = request.split(" ", 3);
                String source = requestArray[1]; String destination = requestArray[2];

                // Check if the destination exists AND is connected by getting its socket
                Socket clientDestination = getClientSocket(destination);
                if (clientDestination == null) { // if the destination does not exist or is not connected
                    if (usernameAlreadyExists(destination)) { // the username exists which means that he is not connected
                        toClient.println("You want to start a conversation with " + destination + " but it seems that this user is not connected for the moment. Try again later...");
                    } else { // if the destination does not exist
                        toClient.println("The user " + destination + " is not an existing one. Please try again and check that there is no typo in the username...");
                    }
                }
                else { // if the destination exists and is connected : THE SERVER TELLS BOTH SOURCE AND DESTINATION THAT A CONVERSATION STARTS BETWEEN THEM
                    // the server tells the "destination" user that the "source" user wants to start a conversation with him (request)
                    PrintWriter toDestinationClient = new PrintWriter(clientDestination.getOutputStream(), true);
                    toDestinationClient.println("talkWithRequest " + source); // we tell the destination that source wanna talk with him

                    // the server tells the "source" user that the conversation with the "destination" user is starting (validation)
                    toClient.println("talkWithValidation " + destination); // we confirm to the source that he is now talking to destination
                }
            }

            if (request.equals("PASSWORD")){ // IF THE CLIENT WANTS TO CHANGE ITS PASSWORD
                // Previous password to authenticate
                // (1) Nonce generation
                String nonceString = getNonce();
                // (2) Challenge : sends the nonce to the client
                toClient.println("challengeNewPW " + nonceString);
                // (3) Response : from the client, the server receives H(H(password)+nonceString) and it must generate it here too and compare : if they match, the authentication is done; otherwise, the user must try again.
                String hashedPWandNonce = fromClient.readLine();
                // (4) Find in the database H(pw) and generate the real H(H(pw)+nonce)
                String realHashedPW = getRealHashedPW(username);
                String realHashedPWandNonce = String.valueOf((realHashedPW+nonceString).hashCode());
                // (5) Authentication : comparison of the two H(H(pw)+nonce)
                while (!realHashedPWandNonce.equals(hashedPWandNonce)) { // We must repeat until it does match ; otherwise, the authentication fails
                    nonceString = getNonce(); // (1)
                    toClient.println("tryAgainChallengeNewPW " + nonceString); // (2)
                    hashedPWandNonce = fromClient.readLine(); // (3)
                    realHashedPW = getRealHashedPW(username); // (4)
                    realHashedPWandNonce = String.valueOf((realHashedPW+nonceString).hashCode()); // (4)
                    // go to (5)
                }
                // Asks the client its new hashed password
                toClient.println("newPassword");
                String passwordHash = fromClient.readLine();

                // The server tells the client that its password is correctly changed
                toClient.println("OKnewPassword");

                // We must save the username + passwordHash in a database
                newPassword(username, passwordHash);
            }

            if (request.startsWith("message")) { // IF THE CLIENT WANTS TO SEND A MESSAGE TO A DESTINATION CLIENT
                String[] requestArray = request.split(" ", 4);
                String destination = requestArray[1]; String source = requestArray[2]; String cypher = requestArray[3];

                // Date and time generation
                String dateAndTime = getDateAndTime();

                // Check if the destination is connected (since the existence of the destination is already validated because the conversation has started previously ...)
                Socket clientDestination = getClientSocket(destination);
                if (clientDestination == null) { // if the destination is not connected
                    toClient.println("The message has been sent but it seems that " + destination + " is not connected now ..."); // The destination will still get the message once he is logged in again because the encrypted message is stored in any case (see below)
                }
                else { // if the destination connected : THE SERVER SENDS THE MESSAGE TO THE DESTINATION CLIENT
                    PrintWriter toDestinationClient = new PrintWriter(clientDestination.getOutputStream(), true);
                    toDestinationClient.println("messageFrom " + dateAndTime + " " + source + " " + cypher); // we tell the destination that source sent the encrypted message cypher
                }

                // In any case (destination connected or not), the server stores the encrypted message in the database
                storeEncryptedMessage(dateAndTime, source, destination, cypher);
            }

            if (request.startsWith("shareGeneratedKey")) { // IF A CLIENT WANTS TO SHARE ITS PUBLIC KEY TO ANOTHER CLIENT (DH Algorithm)
                String[] requestArray = request.split(" ", 4);
                String source = requestArray[1]; String destination = requestArray[2]; String generatedKey = requestArray[3];

                // Check if the destination is connected (since the existence of the destination is already validated because the conversation has validated previously ...)
                Socket clientDestination = getClientSocket(destination);
                if (clientDestination == null) { // if the destination is not connected
                    toClient.println("You tried to send a generated key to " + destination + " but it seems that this user is not connected or does not exist ... Please try again.");
                }
                else { // if the destination is connected
                    PrintWriter toDestinationClient = new PrintWriter(clientDestination.getOutputStream(), true);
                    toDestinationClient.println("shareGeneratedKey " + source + " " + generatedKey); // the server tells the destination that source sent the public key
                }
            }

        }
    }

    private void newPassword(String username, String passwordHash) throws IOException {
        /*
        Called when a user changed its password : We should change the Hash(PW) in the database
        INPUTS :
            username : String : the username of the user who changed its password
            passwordHash : String : the hash of the password in String
         */
        BufferedReader file = new BufferedReader(new FileReader(UsersAndPasswordDATABASE));
        StringBuffer inputBuffer = new StringBuffer();
        String line;

        while ((line = file.readLine()) != null) {
            String[] lineArray = line.split(" ", 2);
            if (lineArray[0].equals(username)) { // the corresponding line is found
                line = username + " " + passwordHash; // we replace the line here
            }
            inputBuffer.append(line);
            inputBuffer.append('\n');
        }
        file.close();
        // Write the new string with the line replaced over the file
        FileOutputStream fileOut = new FileOutputStream(UsersAndPasswordDATABASE);
        fileOut.write(inputBuffer.toString().getBytes());
        fileOut.close();
    }

    private void sendConnectedUsers(PrintWriter toClient) throws IOException {
        /*
        Send the list of all the connected users to the asking client
        INPUT :
            toClient : PrintWriter : the writer of the client asking the history
         */
        int numberOfConnectedUsers = 0;
        String listOfConnectedUsers = "";
        // Check if the file is readable
        if (Files.isReadable(Path.of(connectedUsersDATABASE))){
            FileReader reader = new FileReader(connectedUsersDATABASE);
            BufferedReader bufferedReader = new BufferedReader(reader);
            String line;
            while ((line = bufferedReader.readLine()) != null) {
                numberOfConnectedUsers += 1;
                // add each line to the list
                listOfConnectedUsers += line + " ";
            }
            bufferedReader.close();
        }
        String res = listOfConnectedUsers.substring(0,listOfConnectedUsers.length()-1); // Remove the " " at the end ...
        toClient.println("connectedUsers " + numberOfConnectedUsers + " " + res);
    }

    private String getDateAndTime() {
        /*
        Returns the date and the time when this function is called
        OUTPUT :
            dateAndTime : String : the date and time in a String format
         */
        Date date = new Date();
        Timestamp ts=new Timestamp(date.getTime());
        SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd|HH:mm:ss");
        String dateAndTime = formatter.format(ts);
        return dateAndTime;

    }

    private void sendConvHistory(ArrayList<String> users, PrintWriter toClient) throws IOException {
        /*
        Send the conversation history of a conversation between users to a certain user (using its corresponding writer)
        INPUTS :
            users : ArrayList<String> : arraylist of two users for which a user wants to get the conversation history
            toClient : PrintWriter : the writer of the client asking the history
         */
        // Generate the fileName : username1-username2.txt
        Collections.sort(users); // The names are in the alphabetic order
        String fileName = conversationsPath + users.get(0) + "-" + users.get(1) + ".txt";
        // Check if the file is readable
        if (Files.isReadable(Path.of(fileName))){
            FileReader reader = new FileReader(fileName);
            BufferedReader bufferedReader = new BufferedReader(reader);
            String line;
            while ((line = bufferedReader.readLine()) != null) {
                // Sends line by line to the client with the keyword "convHistory"
                toClient.println("convHistory " + line);
            }
            bufferedReader.close();
        }
    }

    private String getNonce() {
        /*
        Generates a random nonce needed for the authentication
        OUTPUT :
            nonce : String : the generated nonce
         */
        byte[] nonceBytes = new byte[12];
        new SecureRandom().nextBytes(nonceBytes);
        return new String(nonceBytes, StandardCharsets.UTF_8);
    }

    private void storeEncryptedMessage(String dateAndTime, String source, String destination, String cypher) throws IOException {
        /*
        Saves in the database an encrypted message sent at a certain time by a "source" user to a "destination" user
        INPUTS :
            dateAndTime : String : date and time in a String format
            source : String : the username of the source of the message
            destination : String : the username of the destination of the message
            cypher : String : the encrypted message
         */
        // Sorting the user in alphabetic order
        ArrayList<String> users = new ArrayList<String>(); users.add(source); users.add(destination);
        Collections.sort(users); // The names are in the alphabetic order

        // Generating the name of the file used to save the encrypted messages
        String fileName = conversationsPath + users.get(0) + "-" + users.get(1) + ".txt";

        // Generating the line to be saved in the file
        String lineToSave = dateAndTime + " " + source + " " + destination + " " + cypher;

        // Writing
        saveInDatabase(lineToSave, fileName);
    }

    private void saveInDatabase(String lineToSave, String fileName) throws IOException {
        /*
        Saves a certain line in a specific database
        INPUTS :
            lineToSave : String : the line to be saved
            fileName : the name of the database file (.txt)
         */
        FileWriter writer = new FileWriter(fileName, true);
        BufferedWriter bufferedWriter = new BufferedWriter(writer);
        bufferedWriter.write(lineToSave);
        bufferedWriter.write("\r\n");   // write new line
        bufferedWriter.close();
    }

    private void userDisconnected(String userToDisconnect) throws IOException {
        /*
        Takes into account the disconnection of a user
        INPUT :
            userToDisconnect : String : the username of the user disconnecting
         */
        // Check in the database "connectedUsers.txt" if the user is already connected or not
        if (Files.isReadable(Path.of(connectedUsersDATABASE))){
            File inputFile = new File(connectedUsersDATABASE);

            FileReader reader = new FileReader(connectedUsersDATABASE);
            BufferedReader bufferedReader = new BufferedReader(reader);

            // Opens a temporary file to write the client which are still connected
            FileWriter tempWriter = new FileWriter(tempFile, false); // we rewrite everything in a temp file
            BufferedWriter bufferedTempWriter = new BufferedWriter(tempWriter);

            String line;
            while ((line = bufferedReader.readLine()) != null) {
                String[] requestArray = line.split(" ", 2);
                String connectedUser = requestArray[0];
                if (!userToDisconnect.equals(connectedUser)){ // if the user is not the one to disconnect
                    bufferedTempWriter.write(connectedUser); // write its username in the temporary file
                    bufferedTempWriter.write("\r\n");
                }
            }

            bufferedTempWriter.close();
            bufferedReader.close();
            // Delete the old database file and rename the temp one into the new one
            inputFile.delete();
            boolean b = (new File(tempFile)).renameTo(new File(connectedUsersDATABASE));
        }

        // Remove the user from the ArrayList<>'s keeping its username + its corresponding socket
        int index = connectedClients_usernames.indexOf(userToDisconnect);
        if (index != -1) {
            connectedClients_usernames.remove(index);
            connectedClients_sockets.remove(index);
        }
    }

    private boolean userAlreadyConnected(String username) throws IOException {
        /*
        Checks if a user is already connected or not
        INPUT :
            username : String : the username of the user
        OUTPUT :
            isConnected : boolean : true if the user is connected, false otherwise
         */
        if (Files.isReadable(Path.of(connectedUsersDATABASE))){
            FileReader reader = new FileReader(connectedUsersDATABASE);
            BufferedReader bufferedReader = new BufferedReader(reader);

            String line;

            while ((line = bufferedReader.readLine()) != null) {
                String[] requestArray = line.split(" ", 2);
                String connectedUser = requestArray[0];
                if (username.equals(connectedUser)){ // if we meet the username in the database
                    bufferedReader.close();
                    return true; // then the user is connected
                }
            }
            bufferedReader.close();
        }
        return false; // if we have not met the user in the database
    }

    private void initialization() throws IOException {
        /*
        Initializes the database UsersConnectedDATABASE which needs to be cleaned => when the server is launched, there is 0 client connected
         */
        FileWriter writer = new FileWriter(connectedUsersDATABASE, false); // false : because we want to overwrite and not keep what is into the .txt
        BufferedWriter bufferedWriter = new BufferedWriter(writer);
        bufferedWriter.write("");
        bufferedWriter.close();
    }

    private void newUserSignedUp(String username, String passwordHash) throws IOException {
        /*
        Called when a new used signed up => Saves its username and Hash(Password) in a database
         */
        // Generates the line to be saved
        String lineToSave = username + " " + passwordHash;

        // Writing
        saveInDatabase(lineToSave, UsersAndPasswordDATABASE);
    }

    private void userConnected(String username, Socket socket) throws IOException {
        /*
        Called when a user is connected (by signing in or logging in) => Saves its username in a database and by adding its username + its corresponding socket in ArrayList<>'s
        INPUT :
            username : String : the username of the user connected
            socket : Socket : the socket of the user connected
         */
        // Writing in database
        saveInDatabase(username, connectedUsersDATABASE);

        // Update of ArrayList<>'s
        connectedClients_sockets.add(socket);
        connectedClients_usernames.add(username);
    }

    private String getRealHashedPW(String username) throws IOException {
        /*
        Give the hashed password of the username thanks to the database "existingUsersAndPasswords.txt"
        INPUT :
            username : String : the username of the user the server wants to get the hashed password
        OUTPUT :
            realHashedPW : String : the real hashed password present in the database
         */
        if (Files.isReadable(Path.of(UsersAndPasswordDATABASE))){
            FileReader reader = new FileReader(UsersAndPasswordDATABASE);
            BufferedReader bufferedReader = new BufferedReader(reader);

            String line;

            while ((line = bufferedReader.readLine()) != null) {
                String[] requestArray = line.split(" ", 2);
                String usernameInDatabase = requestArray[0];
                if (username.equals(usernameInDatabase)){ // if the username matches with the one in the database
                    bufferedReader.close();
                    return requestArray[1]; // because in this database, we have "username realHashedPassword"
                }
            }
            bufferedReader.close();
        }
        System.out.println("error");
        return "error"; // if it has not find the username in the database : no hashedPassword : "error"
    }

    private boolean correctNewUsername(String username) throws IOException {
        /*
        Checks if the proposal for a username is available (i.e. does not already exist AND contains no spaces)
        INPUT :
            username : String : the proposed username
        OUTPUT :
            isCorrectNewUsername : boolean : true if the username is validated, false otherwise
         */
        return !usernameAlreadyExists(username) && !username.contains(" ");
    }

    private boolean usernameAlreadyExists(String username) throws IOException {
        /*
        Checks in the database "existingUsersAndPasswords.txt" is the username is already taken or not
        INPUT :
            username : String : the username to be checked
        OUTPUT :
            alreadyExists : boolean : true if the username already exists, false otherwise
         */
        if (Files.isReadable(Path.of(UsersAndPasswordDATABASE))){
            FileReader reader = new FileReader(UsersAndPasswordDATABASE);
            BufferedReader bufferedReader = new BufferedReader(reader);

            String line;

            while ((line = bufferedReader.readLine()) != null) {
                String[] requestArray = line.split(" ", 2);
                String existingUsername = requestArray[0];
                if (username.equals(existingUsername)){ // if it founds the username is the list of existing usernames
                    bufferedReader.close();
                    return true; // then the username already exists
                }
            }
            bufferedReader.close();
        }
        return false; // if it has not met the username, then the latter does not already exist
    }

    private Socket getClientSocket(String username) throws IOException {
        /*
        Gives the socket of a certain user
        INPUT :
            username : String : the username of the user
        OUTPUT :
            socket : Socket : the socket of the corresponding user
         */
        Socket socket = null;
        if (userAlreadyConnected(username)) {
            int index = connectedClients_usernames.indexOf(username);
            if (index == -1) { // if the username does not exist ...
                return null;
            }
            socket = connectedClients_sockets.get(index);
        }
        return socket;
    }
}

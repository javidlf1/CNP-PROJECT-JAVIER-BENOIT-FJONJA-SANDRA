package model;

import javax.crypto.*;
import javax.crypto.spec.SecretKeySpec;
import java.io.*;
import java.net.Socket;
import java.nio.file.Files;
import java.nio.file.Path;
import java.security.*;
import java.security.spec.InvalidKeySpecException;
import java.security.spec.X509EncodedKeySpec;
import java.util.ArrayList;
import java.util.Base64;
import java.util.Objects;

public class Client {

    private String username = null;
    private boolean loggedIn = false;
    private String currentConversation = null;

    private volatile boolean listening = true;

    private final Socket socket;
    private final BufferedReader fromServer;
    private final BufferedReader keyboard;
    private final PrintWriter outToServer;
    private final String symKeysDATABASEpath;
    private final String blacklistsDATABASEpath;
    private final String tempFile;

    public Client(String host, int PORT, String symKeysDATABASEpath, String blacklistsDATABASEpath, String tempFile) throws IOException {
        // ---------------------------------------------- INITIALIZATION ----------------------------------------------
        // SOCKET
        this.socket = new Socket(host, PORT);

        // RECEIVING PART (getting a message from the server and manage it)
        this.fromServer = new BufferedReader(new InputStreamReader(socket.getInputStream()));

        // SENDING PART (getting a message from the keyboard and manage it to send it to the server)
        this.keyboard = new BufferedReader(new InputStreamReader(System.in));
        this.outToServer = new PrintWriter(socket.getOutputStream(), true);

        // PATHs initialization
        this.symKeysDATABASEpath = symKeysDATABASEpath;
        this.blacklistsDATABASEpath = blacklistsDATABASEpath;
        this.tempFile = tempFile;
    }


    // ----------------------------------------------------- MAIN -----------------------------------------------------

    public void run() throws IOException {

        // ---------------------------------------- INFORMATION FOR THE CLIENT ----------------------------------------
        information();

        // ----------------------------------------------- LOGGING IN -------------------------------------------------
        String serverResponse;
        String request;
        while (!loggedIn) {
            serverResponse = fromServer.readLine();
            if (serverResponse.startsWith("passwordSignIn")) { // IF THE SERVER ASKS THE PASSWORD WHEN SIGNING IN (send H(PW))
                System.out.println("Server says : What is your password ?");
                String PW = keyboard.readLine();
                String passwordHashed = String.valueOf((PW).hashCode());
                outToServer.println(passwordHashed); // send to server
            } else if (serverResponse.startsWith("challenge")) { // IF THE SERVER ASKS THE PASSWORD WHEN LOGGING IN (receive the nonce and send H(H(PW)+nonce))
                String[] ans = serverResponse.split(" ", 2);
                String nonce = ans[1];
                System.out.println("Server says : What is your password ?");
                String PW = keyboard.readLine();
                String hashedPWandNonce = String.valueOf(((PW.hashCode()) + nonce).hashCode());
                outToServer.println(hashedPWandNonce); // send to server
            } else if (serverResponse.startsWith("tryAgainChallenge")) { // IF THE SERVERS ASKS AGAIN THE PASSWORD WHEN LOGGING IN (receive a new nonce and send H(H(PW)+nonce))
                String[] ans = serverResponse.split(" ", 2);
                String nonce = ans[1];
                System.out.println("Server says : Either the password is not good or there is an authentication problem, please try again. What is your password ?");
                String PW = keyboard.readLine();
                String hashedPWandNonce = String.valueOf(((PW.hashCode()) + nonce).hashCode());
                outToServer.println(hashedPWandNonce); // send to server
            } else if (serverResponse.startsWith("Logged in.")) { // IF THE SERVER TELLS THE CLIENT HE CORRECTLY LOGGED IN
                serverResponse = fromServer.readLine(); // The "Logged in." message is followed by the username of the user
                loginDone(serverResponse); // the client must remember its username
                System.out.println("You are correctly logged in with the username : " + serverResponse);
            } else { // Any other condition : we write the server response, then we check if the client wants to quit and close its socket if it is the case, otherwise we just send the request to the server.
                System.out.println("Server says : " + serverResponse);
                request = keyboard.readLine();
                if (checkIfWeCanQuit(request, serverResponse)){
                    outToServer.println(request);
                    socket.close();
                    System.exit(0);
                } else {
                    outToServer.println(request);
                }
            }
        }


        // -------------------------------------------- THREADS LAUNCHING  --------------------------------------------

        // Receiving : this thread will always listen to the server and act on the server's request
        new Thread(() -> {
            try {
                serverListening();
            } catch (IOException | NoSuchAlgorithmException | InvalidKeySpecException | InvalidKeyException | NoSuchPaddingException | IllegalBlockSizeException | BadPaddingException e) {
                e.printStackTrace();
            }
        }).start();

        // Sending : this thread will always listen to the terminal and send the message to the server (depending on the request of the user)
        new Thread(() -> {
            try {
                serverSending();
            } catch (IOException | InterruptedException | NoSuchPaddingException | IllegalBlockSizeException | NoSuchAlgorithmException | BadPaddingException | InvalidKeyException e) {
                e.printStackTrace();
            }
        }).start();
    }

    private void information() {
        /*
        It just writes text to let the user know basic information when launching the client
         */
        System.out.println("-------------------------------------------------------------------------------------");
        System.out.println("First, you must SIGN UP or LOGIN. Follow the steps ...");
        System.out.println();
        System.out.println("When you are logged in, you can use all the following commands :");
        System.out.println("USERS : to know all the connected users.");
        System.out.println("HISTORY username : loads all the conversation you had with the user USERNAME before.");
        System.out.println("TALK username : starts (or continue) a conversation with USERNAME (if he is connected).");
        System.out.println("EXIT : makes you leave the current conversation. You can then go back to another one (or the same one) using 'talkTo USERNAME' again.");
        System.out.println("FRIENDS : to know all your friends (i.e. the users you already talked with and are not blocked).");
        System.out.println("PASSWORD : if you want to change your password.");
        System.out.println("BLOCK username : blocks a user, impossible to you to receive any message from him until you unblock him.");
        System.out.println("UNBLOCK username : unblocks a user.");
        System.out.println("QUIT : disconnects you from the server.");
        System.out.println();
        System.out.println("-------------------------------------------------------------------------------------");
    }

    private void loginDone(String name) {
        /*
         * When the client correctly logged in, he must remember its username and know that he is logged in
         *
         * INPUT : String name : the username of the client
         * */
        username = name;
        loggedIn = true;
    }

    private boolean checkIfWeCanQuit(String request, String serverResponse) {
        boolean cond1 = request.equals("quit");
        boolean cond2 = !serverResponse.equals("What is your username ?");
        boolean cond3 = !serverResponse.equals("What is your password ?");
        boolean cond4 = !serverResponse.equals("This username seems to already be connected here ... Please try again with another account or sign up");
        boolean cond5 = !serverResponse.equals("This username does not exist, please try again or sign up. What is your username ?");
        boolean cond6 = !serverResponse.startsWith("tryAgainChallenge");
        boolean cond7 = !serverResponse.startsWith("challenge");
        boolean res = cond1 && cond2 && cond3 && cond4 && cond5 && cond6 && cond7;
        return res;
    }

    /*
    private void sayVariable() throws InterruptedException {
        while (true) {
            System.out.println(loggedIn);
            Thread.sleep(3000);
        }
    }
    */

    // ----------------------------------------------- SERVER LISTENING -----------------------------------------------

    private void serverListening() throws IOException, NoSuchAlgorithmException, InvalidKeySpecException, InvalidKeyException, NoSuchPaddingException, IllegalBlockSizeException, BadPaddingException {
        /*
        Thread listening to the server and acting on its responses
         */
        while (true) {
            // (1) Listens to the server
            String serverResponse = fromServer.readLine();

            // (2) Acts on the server request (response)
            if (serverResponse != null) {
                if (serverResponse.startsWith("talkWithValidation")) { // IF THE SERVER VALIDATES TO THE CLIENT THAT HE CAN TALK WITH ANOTHER CLIENT
                    String otherClient = serverResponse.substring(serverResponse.indexOf(' ') + 1); // we delete the "talkWith" part

                    // First, check if we already talked with the other client (i.e. we already have a private shared key), if we don't : DH
                    String sharedKey_str = getSharedKeyWith(otherClient);
                    if (sharedKey_str == null) { // We don't have a sharedKey yet : DH
                        // (1) Generate a pair of key
                        final KeyPair keyPair = getKeyPair();
                        PrivateKey privateKey = keyPair.getPrivate();
                        PublicKey publicKey  = keyPair.getPublic();

                        // (2) Send the public key to the other client through the server
                        // from PublicKey (to byte[]) to String
                        String publicKey_string = getPublicKey_str(publicKey);
                        // sends its publicKey (String)
                        outToServer.println("shareGeneratedKey " + username + " " + otherClient + " " + publicKey_string); // We ask the server to share the generated key to the other client

                        // (3) Receive the public key from the other client through the server
                        serverResponse = fromServer.readLine();
                        while (!(serverResponse.startsWith("shareGeneratedKey"))){serverResponse = fromServer.readLine();}
                        String[] request = serverResponse.split(" ", 3);
                        // maybe add here a verification that the username matches (request[1]) ?
                        String publicKeyReceived_str = request[2];
                        // from String (to byte[]) to PublicKey
                        PublicKey publicKeyReceived = getPublicKeyReceived_PublicKey(publicKeyReceived_str);

                        // (4) Generate the shared key
                        byte[] secretKey = getSecretKey(publicKeyReceived, privateKey);


                        // (6) Save the sharedKey in database
                        savePrivateKeyDatabase(secretKey, otherClient);

                    }

                    // THE CONVERSATION (RE)STARTS
                    newConversation(otherClient); // we inform the client its current conversation has changed

                } else if (serverResponse.startsWith("talkWithRequest")) { // IF THE SERVER TELLS TO THE CLIENT THAT A CLIENT TRY TO REACH HIM
                    String otherClient = serverResponse.substring(serverResponse.indexOf(' ') + 1); // we delete the "talkWith" part

                    // First, check if we already talked with the other client (i.e. we already have a private shared key), if we don't : DH
                    String sharedKey_str = getSharedKeyWith(otherClient);
                    if (sharedKey_str == null) { // We don't have a sharedKey yet : DH
                        // (1) Generate a pair of key
                        final KeyPair keyPair = getKeyPair();
                        PrivateKey privateKey = keyPair.getPrivate();
                        PublicKey publicKey  = keyPair.getPublic();

                        // (2) Send the public key to the other client through the server
                        // from PublicKey (to byte[]) to String
                        String publicKey_string = getPublicKey_str(publicKey);
                        // sends its publicKey (String)
                        outToServer.println("shareGeneratedKey " + username + " " + otherClient + " " + publicKey_string); // We ask the server to share the generated key to the other client

                        // (3) Receive the public key from the other client through the server
                        serverResponse = fromServer.readLine();
                        while (!(serverResponse.startsWith("shareGeneratedKey"))){serverResponse = fromServer.readLine();}
                        String[] request = serverResponse.split(" ", 3);
                        // maybe add here a verification that the username matches (request[1]) ?
                        String publicKeyReceived_str = request[2];
                        // from String (to byte[]) to PublicKey
                        PublicKey publicKeyReceived = getPublicKeyReceived_PublicKey(publicKeyReceived_str);

                        // (4) Generate the shared key
                        byte[] secretKey = getSecretKey(publicKeyReceived, privateKey);


                        // (6) Save the sharedKey in database
                        savePrivateKeyDatabase(secretKey, otherClient);

                    }

                    // INFORM THE CLIENT THAT ANOTHER CLIENT IS STARTING A CONVERSATION WITH THE CLIENT
                    if (!otherClient.equals(currentConversation) && !isBlocked(otherClient)) { // notif only if we are not already in the conversation and if the client is not blocked
                        System.out.println("[NOTIFICATION] " + otherClient + " is starting a conversation with you.");
                    }

                } else if (serverResponse.startsWith("messageFrom")) { // IF SOMEONE SENT A MESSAGE TO THE CLIENT (through de server ...)
                    String[] request = serverResponse.split(" ", 4);
                    String dateAndTime = request[1];
                    String source = request[2];
                    String cypher = request[3];

                    // Is the source of the message blocked ?
                    if (!isBlocked(source)) {
                        // We need to check if we are already talking to someone else : if it is, it update our currentConversation
                        if (!Objects.equals(source, currentConversation)) { // if the client is talking to anyone else : notification
                            // Display of the notification
                            System.out.println("[NOTIFICATION] " + source + " sent you a message !");
                        } else { // if the client is already talking with the source
                            // (1) Decryption of the cypher
                            String secretMessage = decryption(cypher, source);

                            // (2) Display of the decrypted message
                            System.out.println("[" + dateAndTime + "] [" + source + "] " + secretMessage);
                        }
                    }
                } else if (serverResponse.startsWith("connectedUsers")) { // If the user asked to get the connected users, the server sends the list of connected users
                    // Generates the text to say depending on the server response
                    String textToDisplay = getTextConnectedUsers(serverResponse);
                    // Display the text
                    System.out.println(textToDisplay);
                } else if (serverResponse.startsWith("convHistory")) { // If we asked to get the history of a conv, we get all the messages
                    String[] responseArray = serverResponse.split(" ", 5);
                    String dateAndTime = responseArray[1];
                    String source = responseArray[2];
                    String destination = responseArray[3];
                    String cypher = responseArray[4];

                    // Understand who's the other client we had discussed with to search for the corresponding shared key
                    String keyPeerUsername = source;
                    if (keyPeerUsername.equals(username)){
                        keyPeerUsername = destination;
                    }

                    // Decryption of the message knowing who's the corresponding client to find the key
                    String secretMessage = decryption(cypher, keyPeerUsername);
                    System.out.println("[" + dateAndTime + "] [" + source + "] " + secretMessage);
                } else if (serverResponse.startsWith("newPassword")) { // IF THE SERVER ASKS THE PASSWORD WHEN SIGNING IN (send H(PW))
                    System.out.println("Server says : What is your new password ?");
                    String PW = keyboard.readLine();
                    String passwordHashed = String.valueOf((PW).hashCode());
                    outToServer.println(passwordHashed); // send to server
                } else if (serverResponse.startsWith("OKnewPassword")) { // IF THE SERVER ASKS THE PASSWORD WHEN SIGNING IN (send H(PW))
                    System.out.println("Server says : You password has been correctly updated !");
                    listening = true; // the server listener can listen again
                } else if (serverResponse.startsWith("tryAgainChallengeNewPW")) { // IF THE SERVERS ASKS AGAIN THE PASSWORD WHEN TRYING TO CHANGE THE PASSWORD (authentication)
                    String[] ans = serverResponse.split(" ", 2);
                    String nonce = ans[1];
                    System.out.println("Server says : Either the password is not good or there is an authentication problem, please try again. What is your password ?");
                    String PW = keyboard.readLine();
                    String hashedPWandNonce = String.valueOf(((PW.hashCode()) + nonce).hashCode());
                    outToServer.println(hashedPWandNonce); // send to server
                } else if (serverResponse.startsWith("challengeNewPW")) { // IF THE SERVER ASKS THE CURRENT PASSWORD WHEN TRYING TO CHANGE THE PASSWORD (authentication)
                    String[] ans = serverResponse.split(" ", 2);
                    String nonce = ans[1];
                    System.out.println("Server says : What is your current password ?");
                    String PW = keyboard.readLine();
                    String hashedPWandNonce = String.valueOf(((PW.hashCode()) + nonce).hashCode());
                    outToServer.println(hashedPWandNonce); // send to server
                } else if (serverResponse.equals("DISCONNECTED")) { // IF THE CLIENT ASKED TO DISCONNECT, THE SERVER TELLS HIM WHEN HE AGREES : we can close the socket.
                    disconnected();
                } else { // otherwise (for any other message which does not correspond to any form above, we just print what the server says ...)
                    System.out.println("Server says : " + serverResponse);
                }
            } else { // If the server crashes for example ... We need to stop the client
                break;
            }
        }
    }

    private boolean isBlocked(String userToCheck) throws IOException {
        /*
        Checks if a user is blocked or not
        INPUT :
            userToCheck : String : the username of the user
        OUTPUT :
            isBlocked : boolean : true if the user is blocked, false otherwise
         */
        String fileName =  blacklistsDATABASEpath + username + ".txt";
        if (Files.isReadable(Path.of(fileName))){
            FileReader reader = new FileReader(fileName);
            BufferedReader bufferedReader = new BufferedReader(reader);

            String line;

            while ((line = bufferedReader.readLine()) != null) {
                if (userToCheck.equals(line)){ // if we meet the username in the database
                    bufferedReader.close();
                    return true; // then the user is blocked
                }
            }
            bufferedReader.close();
        }
        return false; // if we have not met the user in the database
    }

    private String getTextConnectedUsers(String serverResponse) {
        /*
        Generates the text to display on the interface when the server sends the list of connected clients in a response
        INPUT :
            serverResponse : String : the response of the server
         */
        String text = "";

        // Gets the number of connected users
        String[] responseArray = serverResponse.split(" ", 3);
        int numberOfConnectedUsers = Integer.parseInt(responseArray[1]);

        // Creates a list of String containing all the connected users
        String usersList = responseArray[2];
        String[] connectedUsers = usersList.split(" ", numberOfConnectedUsers);

        // Depending on the number of connected users
        if (numberOfConnectedUsers > 1) { // If there is at least one other connected user
            // Initializes a text with the enumeration of users
            String connectedUsersEnumeration = "";
            // Generates this text containing all the connected users separated by an "," without the username of the current client
            for (int i = 0; i< numberOfConnectedUsers; i++){
                String user = connectedUsers[i];
                if (!user.equals(username)){ // if it not the user which is asking who's connected
                    connectedUsersEnumeration += connectedUsers[i] + ", ";
                }
            }
            String res = connectedUsersEnumeration.substring(0,connectedUsersEnumeration.length()-2); // Remove the ", "

            if (numberOfConnectedUsers == 2){ // If there is only one other client
                text = "There is 1 other user connected at the moment : " + res;
            }
            else { // If there are several other clients
                text = "There are " + (numberOfConnectedUsers-1) + " other user(s) connected at the moment : " + res;
            }
        }
        else { // If there is only one user connected, the client is alone
            text = "You are the only one user which is connected at the moment ...";
        }
        return text;
    }

    private String getSharedKeyWith(String otherClient) throws IOException {
        /*
        Checks in the database of the client what is the shared private key he has with the other client : return in String
        INPUT :
            otherClient : String : the username of the other client
        OUTPUT :
            sharedKey : String : the shared private key in String
         */
        // Check in the database of the client if he already have a key with this client
        String path = symKeysDATABASEpath + username + ".txt";
        if (Files.isReadable(Path.of(path))){
            FileReader reader = new FileReader(path);
            BufferedReader bufferedReader = new BufferedReader(reader);
            String line;
            while ((line = bufferedReader.readLine()) != null) {
                String[] requestArray = line.split(" ", 2);
                String username = requestArray[0];
                if (username.equals(otherClient)){
                    bufferedReader.close();
                    return requestArray[1];
                }
            }
            bufferedReader.close();
        }
        return null;
    }

    private KeyPair getKeyPair() throws NoSuchAlgorithmException {
        /*
        DH : Generates the public and private keys in an object KeyPair
        OUTPUT :
            keyPair : KeyPair : the pair of the generated public and private keys
         */
        KeyPairGenerator keyPairGenerator = KeyPairGenerator.getInstance("DH");
        keyPairGenerator.initialize(1024);
        return keyPairGenerator.generateKeyPair();
    }

    private String getPublicKey_str(PublicKey publicKey_PublicKey) {
        /*
        Transform the type of the generated public key from PublicKey to String
        INPUT :
            publicKey_PublicKey : PublicKey : the generated public key in PublicKey
        OUTPUT :
            publicKey_str : String : the generated public key in String
         */
        byte[] publicKey_byte = publicKey_PublicKey.getEncoded(); // from PublicKey to byte[]
        return Base64.getEncoder().encodeToString(publicKey_byte); // from byte[] to String
    }

    private PublicKey getPublicKeyReceived_PublicKey(String publicKeyReceived_str) throws NoSuchAlgorithmException, InvalidKeySpecException {
        /*
        Transform the type of the received public key from String to PublicKey
        INPUT :
            publicKeyReceived_str : String : the received public key in String
        OUTPUT :
            publicKeyReceived_PublicKey : PublicKey : the received public key in PublicKey
         */
        byte[] publicKeyReceived_byte = Base64.getDecoder().decode(publicKeyReceived_str); // from String to byte[]
        KeyFactory keyFactory = KeyFactory.getInstance("DiffieHellman");
        return keyFactory.generatePublic(new X509EncodedKeySpec(publicKeyReceived_byte));
    }

    private byte[] getSecretKey(PublicKey publicKeyReceived, PrivateKey privateKey) throws NoSuchAlgorithmException, InvalidKeyException {
        /*
        DH : Generates the shared secret key using the private key and the received public key
        INPUTS :
            publicKeyReceived : PublicKey : the public key the client received from the other
            privateKey : PrivateKey : the private key the client generated
        OUTPUT :
            secretKey : byte[] : the generated secret key in byte[]
         */
        final KeyAgreement keyAgreement = KeyAgreement.getInstance("DH");
        keyAgreement.init(privateKey);
        keyAgreement.doPhase(publicKeyReceived, true);

        final byte[] shortenedKey = new byte[8];
        System.arraycopy(keyAgreement.generateSecret(), 0, shortenedKey, 0, shortenedKey.length);

        return shortenedKey; // SHARED KEY !
    }

    private void savePrivateKeyDatabase(byte[] secretKey, String otherClient) throws IOException {
        /*
        Saves the generated secret key with the corresponding client in a database (String in .txt)
        INPUTS :
          secretKey : byte[] : the secret key in byte[]
          otherClient : String : the corresponding client
         */
        // byte[] to String
        String secretKey_string_toSaveInDatabase = Base64.getEncoder().encodeToString(secretKey); // Here, we transform de private key into a String and we can save it in a database of the client
        // Save the String in the corresponding database
        String fileName = symKeysDATABASEpath + username + ".txt";
        String lineToSave = otherClient + " " + secretKey_string_toSaveInDatabase;
        saveInDatabase(lineToSave, fileName);
    }

    private void saveInDatabase(String lineToSave, String fileName) throws IOException {
        /*
        Saves a certain line in a specific database
        INPUTS :
            lineToSave : String : the line to be saved
            fileName : the name of the database file (.txt)
         */
        FileWriter writer = new FileWriter(fileName, true);
        BufferedWriter bufferedWriter = new BufferedWriter(writer);
        bufferedWriter.write(lineToSave);
        bufferedWriter.write("\r\n");   // write new line
        bufferedWriter.close();
    }

    private void newConversation(String otherClient) {
        /*
        Called when the client starts a new conversation : it updates its currentConversation and display all the saved conversation
        INPUT :
            otherClient : String : the username of the new conversation user
         */

        // UPDATE
        currentConversation = otherClient;
        System.out.println();
        System.out.println("Server says : You are now starting a conversation with " + otherClient);

        // LOAD ALL THE EXISTING CONVERSATION BY ASKING THE SERVER TO SEND THE HISTORY
        System.out.println("------------------------------| " + otherClient + " |------------------------------");
        outToServer.println("conv " + otherClient + " " + username); // the client tells the server he would like to get the history of the messages with this client
    }

    private String decryption(String cypher, String source) throws IOException, NoSuchPaddingException, NoSuchAlgorithmException, InvalidKeyException, IllegalBlockSizeException, BadPaddingException {
        /*
        Decrypts a cypher using a shared key with a certain user
        INPUTS :
            cypher : String : the encrypted message to decrypt
            source : String : the username of the source of the message
        OUTPUT :
            decryptedMessage : String : the decrypted message
         */
        // load the shared key
        byte[] sharedKey = Base64.getDecoder().decode(getSharedKeyWith(source));
        // cypher from String to byte[]
        byte[] cypher_byte = Base64.getDecoder().decode(cypher);
        // decryption into string
        SecretKeySpec keySpec = new SecretKeySpec(sharedKey, "DES");
        Cipher        cipher  = Cipher.getInstance("DES/ECB/PKCS5Padding");
        cipher.init(Cipher.DECRYPT_MODE, keySpec);
        return new String(cipher.doFinal(cypher_byte));
    }

    private void disconnected() throws IOException { // Close the socket and the running program
        socket.close();
        System.exit(0);
    }


    // ------------------------------------------------ SERVER SENDING ------------------------------------------------

    private void serverSending() throws IOException, InterruptedException, NoSuchPaddingException, NoSuchAlgorithmException, InvalidKeyException, IllegalBlockSizeException, BadPaddingException {
        /*
        Thread listening to the terminal and sending to the server the request depending on what it is
         */
        listening = true;
        while (true) { // Always waits for a message to send and waits for an answer from the server
            System.out.print("> "); // To show we are waiting for a request ...
            while (!listening) Thread.onSpinWait();
            // (1) Listen to the user
            String request = keyboard.readLine(); // waits until we write and send a message (using the keyboard)

            // (2) Acts on the user request (from keyboard)
            if (request.equals("USERS")) { // IF THE USER WANTS TO KNOW THE CONNECTED USERS
                outToServer.println(request);
            }
            else if (request.equals("FRIENDS")) { // IF THE USER WANTS TO KNOW ALL THE USERS HE ALREADY STARTS A CONVERSATION WITH
                ArrayList<String> friends = getFriends();
                String textToDisplayFriends = getTextFriends(friends);
                System.out.println(textToDisplayFriends);
            }
            else if (request.startsWith("HISTORY")) { // IF THE USER WANTS TO GET THE HISTORY OF A CONVERSATION WITH SOMEONE
                String[] requestArray = request.split(" ", 2);
                String otherClient = requestArray[1];
                outToServer.println("conv " + otherClient + " " + username); // it tells the server that the user wants to see the conversation with a certain user
            }
            else if (request.equals("EXIT")) { // IF THE USER WANTS TO EXIT ITS CURRENT CONVERSATION TO GO TO ANOTHER ONE
                exitConversation();
            }
            else if (request.equals("PASSWORD")) { // IF THE USER WANTS TO CHANGE ITS PASSWORD
                listening = false;
                exitConversation(); // first the user leaves the current conversation
                outToServer.println(request);
            }
            else if (request.startsWith("BLOCK")) { // IF THE USER WANTS TO BLOCK SOMEONE (i.e. not receive its messages)
                String[] requestArray = request.split(" ", 2);
                String userToBlock = requestArray[1];
                if (!isBlocked(userToBlock)){
                    if (userToBlock.equals(currentConversation)){ // if the user we are blocking is the one we are talking with
                        exitConversation(); // then we leave the conversation
                    }
                    block(userToBlock);
                } else { // if the user is already blocked
                    System.out.println("The user " + userToBlock + " that you want to block is already blocked.");
                }

            }
            else if (request.startsWith("UNBLOCK")) { // IF THE USER WANTS TO UNBLOCK SOMEONE
                String[] requestArray = request.split(" ", 2);
                String userToUnblock = requestArray[1];
                if (isBlocked(userToUnblock)) {
                    unblock(userToUnblock);
                } else { // if the user is not even blocked
                    System.out.println("The user " + userToUnblock + " that you want to unblock is not even blocked.");
                }
            }
            else if (request.equals("QUIT")) { // IF THE USER WANTS TO QUIT
                outToServer.println("quit " + username); // it tells the server that the user want to quit
            }
            else { // otherwise, we are in a conversation or we are trying to enter a conversation
                if (currentConversation == null) { // if the client is not talking to anybody currently
                    if (request.startsWith("TALK")) { // IF THE USER WANTS TO TALK TO ANOTHER USER
                        String[] requestArray = request.split(" ", 2);
                        String destination = requestArray[1];
                        if (!destination.contains(" ")){ // be sure that the username he wants to reach is in one word ...
                            if (!isBlocked(destination)){ // if the destination is not blocked
                                outToServer.println("talkTo " + username + " " + destination);
                            } else { // if the destination is blocked
                                System.out.println("You blocked this user previously, please unblock him before trying to reach him.");
                            }
                        } else { // if the username he entered is not a possible username (i.e. contains spaces ...)
                            System.out.println("Username does not contain spaces into it, try again to enter an existing username ... ('talkTo USERNAME')");
                        }
                    } else { // if the client is not talking to anybody currently but is not asking to talk to somebody
                        talkToAnyone();
                    }
                } else { // If the user is in a discussion with someone and sends a message
                    if (!isBlocked(currentConversation)) { // if the current conv is not blocked
                        // (1) Encrypt the message
                        String encryptedMessage_str = encryption(request, currentConversation);

                        // (2) Send to other client through the server
                        outToServer.println("message " + currentConversation + " " + username + " " + encryptedMessage_str); // You send the following format : "message usernameDestination usernameSource message"
                    } else { // if the current conv is blocked
                        System.out.println("You blocked this user previously, please unblock him before trying to reach him.");
                    }
                }
            }
        }
    }

    private String getTextFriends(ArrayList<String> friends) {
        /*
        Depending on a list of friends, it returns the text to display on the interface of the user when he asks to know its friends (people he already talked with)
        INPUT :
            friends : ArrayList<String> : list of friends
        OUTPUT :
            text : String : the text to display
         */
        int l = friends.size();
        String text = "";
        if (l==0){ // no friend
            text = "You have no friend for the moment ... Try to talk to someone by using the command 'TALK username' !";
        } else if (l == 1) { // 1 friend
            text = "You have 1 friend : " + friends.get(0);
        } else { // more than 1 friend
            for (int i = 0; i<l ; i++){
                text = text + friends.get(i) + ", ";
            }
            text = text.substring(0,text.length()-2); // Remove the ", "
            text = "Your friends : " + text;
        }
        return text;
    }

    private ArrayList<String> getFriends() throws IOException {
        /*
        Return an array list containing the usernames of all the users the client has already talked with
        OUTPUT :
            friends : ArrayList<String> : list of String
         */
        ArrayList<String> friends = new ArrayList<>();
        String path = symKeysDATABASEpath + username + ".txt";
        if (Files.isReadable(Path.of(path))){
            FileReader reader = new FileReader(path);
            BufferedReader bufferedReader = new BufferedReader(reader);
            String line;
            while ((line = bufferedReader.readLine()) != null) {
                String[] requestArray = line.split(" ", 2);
                String friend = requestArray[0];
                if (!isBlocked(friend)) { // if the potential friend is not blocked
                    friends.add(friend);
                }
            }
            bufferedReader.close();
        }
        return friends;
    }

    private void unblock(String userToUnblock) throws IOException {
        /*
        Delete the user from the blacklist database
        INPUT :
            userToUnblock : String : the username of the user to unblock
         */
        String fileName = blacklistsDATABASEpath + username + ".txt";
        if (Files.isReadable(Path.of(fileName))){
            File inputFile = new File(fileName);

            FileReader reader = new FileReader(fileName);
            BufferedReader bufferedReader = new BufferedReader(reader);

            // Opens a temporary file to write the client which are still connected
            FileWriter tempWriter = new FileWriter(tempFile, false); // we rewrite everything in a temp file
            BufferedWriter bufferedTempWriter = new BufferedWriter(tempWriter);

            String line;
            while ((line = bufferedReader.readLine()) != null) {
                String[] requestArray = line.split(" ", 2);
                String connectedUser = requestArray[0];
                if (!userToUnblock.equals(connectedUser)){ // if the user is not the one to disconnect
                    bufferedTempWriter.write(connectedUser); // write its username in the temporary file
                    bufferedTempWriter.write("\r\n");
                }
            }

            bufferedTempWriter.close();
            bufferedReader.close();
            // Delete the old database file and rename the temp one into the new one
            inputFile.delete();
            boolean b = (new File(tempFile)).renameTo(new File(fileName));
            System.out.println("The user " + userToUnblock + " is now unblocked.");
        }
    }

    private void block(String userToBlock) throws IOException {
        /*
        Saves a user to block in a database
        INPUTS :
          userToBlock : String : the username of the user to block
         */
        String fileName = blacklistsDATABASEpath + username + ".txt";
        saveInDatabase(userToBlock, fileName);
        System.out.println("The user " + userToBlock + " has been blocked, you will not receive its messages until you unblock him (using : UNBLOCK " + userToBlock + ").");
    }

    private void exitConversation() {
        /*
        Called when the user wants to leave its current conversation
         */
        currentConversation = null;
        System.out.println("------------------------------------------------------------------------"); // display to "close" the conversation
    }

    private void talkToAnyone() {
        /*
        It just writes text to let the user know he is talking to nobody at the moment ...
         */
        System.out.println("You must open a conversation with someone before trying to send messages ...");
        System.out.println("To do so, you can first check the list of the connected users : 'connectedUsers'");
        System.out.println("You can start a conversation with a connection user by using : 'talkTo USERNAME'");
    }

    private String encryption(String request, String destination) throws IOException, NoSuchPaddingException, NoSuchAlgorithmException, InvalidKeyException, IllegalBlockSizeException, BadPaddingException {
        /*
        Encrypts a message using a shared key with a certain user
        INPUTS :
            message : String : the message to encrypt
            destination : String : the username of the destination of the message
        OUTPUT :
            encryptedMessage_str : String : the encrypted message in String
         */
        // load the shared key
        byte[] sharedKey = Base64.getDecoder().decode(getSharedKeyWith(destination));
        // ecryption into byte[]
        SecretKeySpec keySpec = new SecretKeySpec(sharedKey, "DES");
        Cipher cipher  = Cipher.getInstance("DES/ECB/PKCS5Padding");
        cipher.init(Cipher.ENCRYPT_MODE, keySpec);
        byte[] encryptedMessage = cipher.doFinal(request.getBytes());
        // from byte[] to String
        return Base64.getEncoder().encodeToString(encryptedMessage);
    }
}

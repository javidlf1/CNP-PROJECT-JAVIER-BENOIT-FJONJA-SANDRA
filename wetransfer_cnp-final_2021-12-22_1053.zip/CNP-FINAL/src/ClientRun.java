import java.io.IOException;
import model.Client;

public class ClientRun {

    public static void main(String[] args) throws IOException {
        // Initilization
        String host = "localhost";
        int PORT = 1234;
        String symKeysDATABASEpath = "databaseClients\\symKeys\\";
        String blacklistsDATABASEpath = "databaseClients\\blacklists\\";
        String tempFile = "databaseClients\\blacklists\\temp.txt";

        // Creates the client
        Client c = new Client(host, PORT, symKeysDATABASEpath, blacklistsDATABASEpath, tempFile);

        // Runs the client
        c.run();
    }
}

import java.io.IOException;
import model.Server;

public class ServerRun {

    public static void main(String[] args) throws IOException {
        // Initialization
        int PORT = 1234;
        String UsersAndPasswordDATABASE = "databaseServer\\users\\existingUsersAndPasswords.txt";
        String connectedUsersDATABASE = "databaseServer\\users\\connectedUsers.txt";
        String tempFile = "databaseServer\\users\\temp.txt";
        String conversationsPath = "databaseServer\\encryptedConversations\\";

        // Creates the server
        Server s = new Server(PORT, UsersAndPasswordDATABASE, connectedUsersDATABASE, tempFile, conversationsPath);

        // Runs the server
        s.run();
    }
}
